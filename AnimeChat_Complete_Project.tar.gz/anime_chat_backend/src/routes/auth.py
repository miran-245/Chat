from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from src.models.user import User, db
import json

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    """تسجيل مستخدم جديد"""
    try:
        data = request.get_json()
        
        # التحقق من البيانات المطلوبة
        if not data or not data.get('username') or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'اسم المستخدم والبريد الإلكتروني وكلمة المرور مطلوبة'}), 400
        
        username = data.get('username').strip()
        email = data.get('email').strip().lower()
        password = data.get('password')
        display_name = data.get('display_name', '').strip()
        
        # التحقق من طول كلمة المرور
        if len(password) < 6:
            return jsonify({'error': 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'}), 400
        
        # التحقق من وجود المستخدم
        if User.query.filter_by(username=username).first():
            return jsonify({'error': 'اسم المستخدم موجود بالفعل'}), 400
        
        if User.query.filter_by(email=email).first():
            return jsonify({'error': 'البريد الإلكتروني موجود بالفعل'}), 400
        
        # إنشاء مستخدم جديد
        user = User(
            username=username,
            email=email,
            display_name=display_name if display_name else username
        )
        user.set_password(password)
        
        # إذا كان هذا أول مستخدم، اجعله مدير
        if User.query.count() == 0:
            user.is_admin = True
        
        db.session.add(user)
        db.session.commit()
        
        # إنشاء token
        access_token = create_access_token(identity=user.id)
        
        return jsonify({
            'message': 'تم التسجيل بنجاح',
            'access_token': access_token,
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في التسجيل: {str(e)}'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """تسجيل الدخول"""
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({'error': 'اسم المستخدم وكلمة المرور مطلوبان'}), 400
        
        username = data.get('username').strip()
        password = data.get('password')
        
        # البحث عن المستخدم (يمكن استخدام اسم المستخدم أو البريد الإلكتروني)
        user = User.query.filter(
            (User.username == username) | (User.email == username.lower())
        ).first()
        
        if not user or not user.check_password(password):
            return jsonify({'error': 'اسم المستخدم أو كلمة المرور غير صحيحة'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'تم تعطيل هذا الحساب'}), 403
        
        # تحديث آخر ظهور
        user.update_last_seen()
        
        # إنشاء token
        access_token = create_access_token(identity=user.id)
        
        return jsonify({
            'message': 'تم تسجيل الدخول بنجاح',
            'access_token': access_token,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في تسجيل الدخول: {str(e)}'}), 500

@auth_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """الحصول على ملف المستخدم الشخصي"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        return jsonify({'user': user.to_dict(include_sensitive=True)}), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب الملف الشخصي: {str(e)}'}), 500

@auth_bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """تحديث ملف المستخدم الشخصي"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        data = request.get_json()
        
        # تحديث البيانات المسموح بتعديلها
        if 'display_name' in data:
            user.display_name = data['display_name'].strip()
        
        if 'bio' in data:
            user.bio = data['bio'].strip()
        
        if 'avatar_url' in data:
            user.avatar_url = data['avatar_url'].strip()
        
        if 'favorite_anime' in data:
            # التأكد من أن البيانات في صيغة JSON صحيحة
            try:
                if isinstance(data['favorite_anime'], list):
                    user.favorite_anime = json.dumps(data['favorite_anime'])
                else:
                    user.favorite_anime = data['favorite_anime']
            except:
                return jsonify({'error': 'صيغة الأنميات المفضلة غير صحيحة'}), 400
        
        db.session.commit()
        
        return jsonify({
            'message': 'تم تحديث الملف الشخصي بنجاح',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في تحديث الملف الشخصي: {str(e)}'}), 500

@auth_bp.route('/change-password', methods=['POST'])
@jwt_required()
def change_password():
    """تغيير كلمة المرور"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        data = request.get_json()
        
        if not data or not data.get('current_password') or not data.get('new_password'):
            return jsonify({'error': 'كلمة المرور الحالية والجديدة مطلوبتان'}), 400
        
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        # التحقق من كلمة المرور الحالية
        if not user.check_password(current_password):
            return jsonify({'error': 'كلمة المرور الحالية غير صحيحة'}), 401
        
        # التحقق من طول كلمة المرور الجديدة
        if len(new_password) < 6:
            return jsonify({'error': 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل'}), 400
        
        # تحديث كلمة المرور
        user.set_password(new_password)
        db.session.commit()
        
        return jsonify({'message': 'تم تغيير كلمة المرور بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في تغيير كلمة المرور: {str(e)}'}), 500

