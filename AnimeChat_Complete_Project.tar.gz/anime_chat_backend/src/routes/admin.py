from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.chat import ChatRoom, ChatMember, Message, BlockedUser
from datetime import datetime, timedelta

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """ديكوريتر للتحقق من صلاحيات المدير"""
    def decorated_function(*args, **kwargs):
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        if not user or not user.is_admin:
            return jsonify({'error': 'ليس لديك صلاحيات المدير'}), 403
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/dashboard', methods=['GET'])
@jwt_required()
@admin_required
def get_dashboard_stats():
    """الحصول على إحصائيات لوحة التحكم"""
    try:
        # إحصائيات عامة
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        total_rooms = ChatRoom.query.count()
        total_messages = Message.query.filter_by(is_deleted=False).count()
        
        # المستخدمون الجدد في آخر 7 أيام
        week_ago = datetime.utcnow() - timedelta(days=7)
        new_users_week = User.query.filter(User.created_at >= week_ago).count()
        
        # الرسائل في آخر 24 ساعة
        day_ago = datetime.utcnow() - timedelta(days=1)
        messages_today = Message.query.filter(Message.created_at >= day_ago, Message.is_deleted == False).count()
        
        # أكثر الغرف نشاطاً
        active_rooms = db.session.query(
            ChatRoom.id, ChatRoom.name, db.func.count(Message.id).label('message_count')
        ).join(Message).filter(Message.is_deleted == False).group_by(ChatRoom.id).order_by(
            db.func.count(Message.id).desc()
        ).limit(5).all()
        
        active_rooms_data = [
            {'room_id': room.id, 'room_name': room.name, 'message_count': room.message_count}
            for room in active_rooms
        ]
        
        return jsonify({
            'stats': {
                'total_users': total_users,
                'active_users': active_users,
                'total_rooms': total_rooms,
                'total_messages': total_messages,
                'new_users_week': new_users_week,
                'messages_today': messages_today
            },
            'active_rooms': active_rooms_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب إحصائيات لوحة التحكم: {str(e)}'}), 500

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@admin_required
def get_all_users():
    """الحصول على قائمة جميع المستخدمين"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        search = request.args.get('search', '')
        
        query = User.query
        
        if search:
            query = query.filter(
                (User.username.contains(search)) | 
                (User.email.contains(search)) |
                (User.display_name.contains(search))
            )
        
        users = query.order_by(User.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        users_data = [user.to_dict(include_sensitive=True) for user in users.items]
        
        return jsonify({
            'users': users_data,
            'pagination': {
                'page': users.page,
                'pages': users.pages,
                'per_page': users.per_page,
                'total': users.total,
                'has_next': users.has_next,
                'has_prev': users.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب المستخدمين: {str(e)}'}), 500

@admin_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
@jwt_required()
@admin_required
def toggle_user_status(user_id):
    """تفعيل/تعطيل مستخدم"""
    try:
        current_admin_id = get_jwt_identity()
        
        if current_admin_id == user_id:
            return jsonify({'error': 'لا يمكنك تعطيل حسابك الخاص'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        user.is_active = not user.is_active
        db.session.commit()
        
        status = 'تم تفعيل' if user.is_active else 'تم تعطيل'
        return jsonify({'message': f'{status} المستخدم بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في تغيير حالة المستخدم: {str(e)}'}), 500

@admin_bp.route('/users/<int:user_id>/make-admin', methods=['POST'])
@jwt_required()
@admin_required
def make_user_admin(user_id):
    """جعل مستخدم مدير"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        if user.is_admin:
            return jsonify({'error': 'المستخدم مدير بالفعل'}), 400
        
        user.is_admin = True
        db.session.commit()
        
        return jsonify({'message': 'تم جعل المستخدم مدير بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في جعل المستخدم مدير: {str(e)}'}), 500

@admin_bp.route('/users/<int:user_id>/remove-admin', methods=['POST'])
@jwt_required()
@admin_required
def remove_user_admin(user_id):
    """إزالة صلاحيات المدير من مستخدم"""
    try:
        current_admin_id = get_jwt_identity()
        
        if current_admin_id == user_id:
            return jsonify({'error': 'لا يمكنك إزالة صلاحيات المدير من حسابك الخاص'}), 400
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        if not user.is_admin:
            return jsonify({'error': 'المستخدم ليس مدير'}), 400
        
        user.is_admin = False
        db.session.commit()
        
        return jsonify({'message': 'تم إزالة صلاحيات المدير بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في إزالة صلاحيات المدير: {str(e)}'}), 500

@admin_bp.route('/rooms', methods=['GET'])
@jwt_required()
@admin_required
def get_all_rooms():
    """الحصول على قائمة جميع غرف الدردشة"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        rooms = ChatRoom.query.order_by(ChatRoom.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        rooms_data = []
        for room in rooms.items:
            room_data = room.to_dict()
            # إضافة معلومات إضافية
            room_data['creator'] = User.query.get(room.created_by).username
            room_data['message_count'] = Message.query.filter_by(room_id=room.id, is_deleted=False).count()
            rooms_data.append(room_data)
        
        return jsonify({
            'rooms': rooms_data,
            'pagination': {
                'page': rooms.page,
                'pages': rooms.pages,
                'per_page': rooms.per_page,
                'total': rooms.total,
                'has_next': rooms.has_next,
                'has_prev': rooms.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب غرف الدردشة: {str(e)}'}), 500

@admin_bp.route('/rooms/<int:room_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_room(room_id):
    """حذف غرفة دردشة"""
    try:
        room = ChatRoom.query.get(room_id)
        if not room:
            return jsonify({'error': 'الغرفة غير موجودة'}), 404
        
        # حذف الغرفة (سيتم حذف الرسائل والأعضاء تلقائياً بسبب cascade)
        db.session.delete(room)
        db.session.commit()
        
        return jsonify({'message': 'تم حذف الغرفة بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في حذف الغرفة: {str(e)}'}), 500

@admin_bp.route('/messages/recent', methods=['GET'])
@jwt_required()
@admin_required
def get_recent_messages():
    """الحصول على الرسائل الأخيرة لمراقبة المحتوى"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        messages = Message.query.filter_by(is_deleted=False).order_by(
            Message.created_at.desc()
        ).paginate(page=page, per_page=per_page, error_out=False)
        
        messages_data = []
        for message in messages.items:
            msg_data = message.to_dict()
            msg_data['room_name'] = ChatRoom.query.get(message.room_id).name
            messages_data.append(msg_data)
        
        return jsonify({
            'messages': messages_data,
            'pagination': {
                'page': messages.page,
                'pages': messages.pages,
                'per_page': messages.per_page,
                'total': messages.total,
                'has_next': messages.has_next,
                'has_prev': messages.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب الرسائل: {str(e)}'}), 500

@admin_bp.route('/broadcast', methods=['POST'])
@jwt_required()
@admin_required
def broadcast_message():
    """إرسال إشعار عام لجميع المستخدمين"""
    try:
        data = request.get_json()
        
        if not data or not data.get('message'):
            return jsonify({'error': 'محتوى الإشعار مطلوب'}), 400
        
        message_content = data.get('message').strip()
        title = data.get('title', 'إشعار من الإدارة').strip()
        
        # هنا يمكن إضافة منطق إرسال الإشعارات
        # مثل إرسال push notifications أو حفظ الإشعارات في قاعدة البيانات
        
        # للآن سنقوم بحفظ الإشعار كرسالة في غرفة عامة خاصة بالإشعارات
        admin_id = get_jwt_identity()
        
        # البحث عن غرفة الإشعارات أو إنشاؤها
        announcements_room = ChatRoom.query.filter_by(name='إشعارات الإدارة').first()
        if not announcements_room:
            announcements_room = ChatRoom(
                name='إشعارات الإدارة',
                description='غرفة خاصة بإشعارات الإدارة',
                is_private=False,
                created_by=admin_id
            )
            db.session.add(announcements_room)
            db.session.flush()
        
        # إنشاء رسالة الإشعار
        announcement = Message(
            room_id=announcements_room.id,
            sender_id=admin_id,
            content=f"📢 {title}\n\n{message_content}",
            message_type='announcement'
        )
        
        db.session.add(announcement)
        db.session.commit()
        
        return jsonify({'message': 'تم إرسال الإشعار بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في إرسال الإشعار: {str(e)}'}), 500

