from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.user import User, db
from src.models.chat import ChatRoom, ChatMember, Message, BlockedUser
from datetime import datetime

chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/rooms', methods=['GET'])
@jwt_required()
def get_chat_rooms():
    """الحصول على قائمة غرف الدردشة"""
    try:
        user_id = get_jwt_identity()
        
        # الحصول على الغرف التي ينتمي إليها المستخدم
        user_rooms = db.session.query(ChatRoom).join(ChatMember).filter(
            ChatMember.user_id == user_id
        ).all()
        
        rooms_data = []
        for room in user_rooms:
            # الحصول على آخر رسالة في الغرفة
            last_message = Message.query.filter_by(room_id=room.id, is_deleted=False).order_by(Message.created_at.desc()).first()
            
            room_data = room.to_dict()
            room_data['last_message'] = last_message.to_dict() if last_message else None
            rooms_data.append(room_data)
        
        return jsonify({'rooms': rooms_data}), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب غرف الدردشة: {str(e)}'}), 500

@chat_bp.route('/rooms', methods=['POST'])
@jwt_required()
def create_chat_room():
    """إنشاء غرفة دردشة جديدة"""
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        if not data or not data.get('name'):
            return jsonify({'error': 'اسم الغرفة مطلوب'}), 400
        
        name = data.get('name').strip()
        description = data.get('description', '').strip()
        is_private = data.get('is_private', False)
        
        # إنشاء الغرفة
        room = ChatRoom(
            name=name,
            description=description,
            is_private=is_private,
            created_by=user_id
        )
        
        db.session.add(room)
        db.session.flush()  # للحصول على ID الغرفة
        
        # إضافة المنشئ كعضو ومدير للغرفة
        member = ChatMember(
            room_id=room.id,
            user_id=user_id,
            is_admin=True
        )
        
        db.session.add(member)
        db.session.commit()
        
        return jsonify({
            'message': 'تم إنشاء الغرفة بنجاح',
            'room': room.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في إنشاء الغرفة: {str(e)}'}), 500

@chat_bp.route('/rooms/<int:room_id>/join', methods=['POST'])
@jwt_required()
def join_chat_room(room_id):
    """الانضمام إلى غرفة دردشة"""
    try:
        user_id = get_jwt_identity()
        
        # التحقق من وجود الغرفة
        room = ChatRoom.query.get(room_id)
        if not room:
            return jsonify({'error': 'الغرفة غير موجودة'}), 404
        
        # التحقق من عدم انضمام المستخدم مسبقاً
        existing_member = ChatMember.query.filter_by(room_id=room_id, user_id=user_id).first()
        if existing_member:
            return jsonify({'error': 'أنت عضو في هذه الغرفة بالفعل'}), 400
        
        # إضافة المستخدم كعضو
        member = ChatMember(
            room_id=room_id,
            user_id=user_id
        )
        
        db.session.add(member)
        db.session.commit()
        
        return jsonify({'message': 'تم الانضمام إلى الغرفة بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في الانضمام إلى الغرفة: {str(e)}'}), 500

@chat_bp.route('/rooms/<int:room_id>/messages', methods=['GET'])
@jwt_required()
def get_room_messages(room_id):
    """الحصول على رسائل غرفة الدردشة"""
    try:
        user_id = get_jwt_identity()
        
        # التحقق من عضوية المستخدم في الغرفة
        member = ChatMember.query.filter_by(room_id=room_id, user_id=user_id).first()
        if not member:
            return jsonify({'error': 'ليس لديك صلاحية للوصول إلى هذه الغرفة'}), 403
        
        # الحصول على المعاملات
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        # الحصول على الرسائل مع التصفح
        messages = Message.query.filter_by(room_id=room_id).order_by(Message.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        messages_data = [msg.to_dict() for msg in messages.items]
        messages_data.reverse()  # ترتيب تصاعدي للعرض
        
        return jsonify({
            'messages': messages_data,
            'pagination': {
                'page': messages.page,
                'pages': messages.pages,
                'per_page': messages.per_page,
                'total': messages.total,
                'has_next': messages.has_next,
                'has_prev': messages.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب الرسائل: {str(e)}'}), 500

@chat_bp.route('/rooms/<int:room_id>/messages', methods=['POST'])
@jwt_required()
def send_message(room_id):
    """إرسال رسالة إلى غرفة الدردشة"""
    try:
        user_id = get_jwt_identity()
        
        # التحقق من عضوية المستخدم في الغرفة
        member = ChatMember.query.filter_by(room_id=room_id, user_id=user_id).first()
        if not member:
            return jsonify({'error': 'ليس لديك صلاحية للإرسال في هذه الغرفة'}), 403
        
        data = request.get_json()
        
        if not data or not data.get('content'):
            return jsonify({'error': 'محتوى الرسالة مطلوب'}), 400
        
        content = data.get('content').strip()
        message_type = data.get('message_type', 'text')
        file_url = data.get('file_url')
        reply_to = data.get('reply_to')
        
        # التحقق من الرسالة المرد عليها إذا كانت موجودة
        if reply_to:
            parent_message = Message.query.filter_by(id=reply_to, room_id=room_id).first()
            if not parent_message:
                return jsonify({'error': 'الرسالة المرد عليها غير موجودة'}), 400
        
        # إنشاء الرسالة
        message = Message(
            room_id=room_id,
            sender_id=user_id,
            content=content,
            message_type=message_type,
            file_url=file_url,
            reply_to=reply_to
        )
        
        db.session.add(message)
        db.session.commit()
        
        return jsonify({
            'message': 'تم إرسال الرسالة بنجاح',
            'data': message.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في إرسال الرسالة: {str(e)}'}), 500

@chat_bp.route('/messages/<int:message_id>', methods=['DELETE'])
@jwt_required()
def delete_message(message_id):
    """حذف رسالة"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        message = Message.query.get(message_id)
        if not message:
            return jsonify({'error': 'الرسالة غير موجودة'}), 404
        
        # التحقق من الصلاحية (المرسل أو المدير)
        if message.sender_id != user_id and not user.is_admin:
            # التحقق من كون المستخدم مدير الغرفة
            member = ChatMember.query.filter_by(room_id=message.room_id, user_id=user_id, is_admin=True).first()
            if not member:
                return jsonify({'error': 'ليس لديك صلاحية لحذف هذه الرسالة'}), 403
        
        # وضع علامة الحذف بدلاً من الحذف الفعلي
        message.is_deleted = True
        message.content = '[تم حذف هذه الرسالة]'
        db.session.commit()
        
        return jsonify({'message': 'تم حذف الرسالة بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في حذف الرسالة: {str(e)}'}), 500

@chat_bp.route('/users/<int:user_id>/block', methods=['POST'])
@jwt_required()
def block_user(user_id):
    """حظر مستخدم"""
    try:
        blocker_id = get_jwt_identity()
        
        if blocker_id == user_id:
            return jsonify({'error': 'لا يمكنك حظر نفسك'}), 400
        
        # التحقق من وجود المستخدم
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'المستخدم غير موجود'}), 404
        
        # التحقق من عدم وجود حظر مسبق
        existing_block = BlockedUser.query.filter_by(blocker_id=blocker_id, blocked_id=user_id).first()
        if existing_block:
            return jsonify({'error': 'المستخدم محظور بالفعل'}), 400
        
        data = request.get_json()
        reason = data.get('reason', '') if data else ''
        
        # إنشاء الحظر
        block = BlockedUser(
            blocker_id=blocker_id,
            blocked_id=user_id,
            reason=reason
        )
        
        db.session.add(block)
        db.session.commit()
        
        return jsonify({'message': 'تم حظر المستخدم بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في حظر المستخدم: {str(e)}'}), 500

@chat_bp.route('/users/<int:user_id>/unblock', methods=['POST'])
@jwt_required()
def unblock_user(user_id):
    """إلغاء حظر مستخدم"""
    try:
        blocker_id = get_jwt_identity()
        
        # البحث عن الحظر
        block = BlockedUser.query.filter_by(blocker_id=blocker_id, blocked_id=user_id).first()
        if not block:
            return jsonify({'error': 'المستخدم غير محظور'}), 400
        
        db.session.delete(block)
        db.session.commit()
        
        return jsonify({'message': 'تم إلغاء حظر المستخدم بنجاح'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'خطأ في إلغاء حظر المستخدم: {str(e)}'}), 500

@chat_bp.route('/blocked-users', methods=['GET'])
@jwt_required()
def get_blocked_users():
    """الحصول على قائمة المستخدمين المحظورين"""
    try:
        user_id = get_jwt_identity()
        
        blocked_users = db.session.query(BlockedUser, User).join(
            User, BlockedUser.blocked_id == User.id
        ).filter(BlockedUser.blocker_id == user_id).all()
        
        blocked_list = []
        for block, user in blocked_users:
            blocked_list.append({
                'block_info': block.to_dict(),
                'user_info': user.to_dict()
            })
        
        return jsonify({'blocked_users': blocked_list}), 200
        
    except Exception as e:
        return jsonify({'error': f'خطأ في جلب المستخدمين المحظورين: {str(e)}'}), 500

