from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect
from flask_jwt_extended import decode_token
from src.models.user import User
from src.models.chat import ChatMember, Message, ChatRoom
from src.models.user import db
import json

socketio = SocketIO(cors_allowed_origins="*")

# قاموس لتتبع المستخدمين المتصلين
connected_users = {}

@socketio.on('connect')
def handle_connect(auth):
    """التعامل مع اتصال المستخدم"""
    try:
        # التحقق من token
        if not auth or 'token' not in auth:
            disconnect()
            return False
        
        token = auth['token']
        try:
            decoded_token = decode_token(token)
            user_id = decoded_token['sub']
        except:
            disconnect()
            return False
        
        # التحقق من وجود المستخدم
        user = User.query.get(user_id)
        if not user or not user.is_active:
            disconnect()
            return False
        
        # حفظ معلومات المستخدم المتصل
        connected_users[request.sid] = {
            'user_id': user_id,
            'username': user.username
        }
        
        # تحديث آخر ظهور
        user.update_last_seen()
        
        emit('connected', {'message': 'تم الاتصال بنجاح'})
        print(f"User {user.username} connected with session {request.sid}")
        
    except Exception as e:
        print(f"Connection error: {str(e)}")
        disconnect()
        return False

@socketio.on('disconnect')
def handle_disconnect():
    """التعامل مع قطع الاتصال"""
    try:
        if request.sid in connected_users:
            user_info = connected_users[request.sid]
            print(f"User {user_info['username']} disconnected")
            del connected_users[request.sid]
    except Exception as e:
        print(f"Disconnect error: {str(e)}")

@socketio.on('join_room')
def handle_join_room(data):
    """الانضمام إلى غرفة دردشة"""
    try:
        if request.sid not in connected_users:
            emit('error', {'message': 'غير مصرح لك'})
            return
        
        user_id = connected_users[request.sid]['user_id']
        room_id = data.get('room_id')
        
        if not room_id:
            emit('error', {'message': 'معرف الغرفة مطلوب'})
            return
        
        # التحقق من عضوية المستخدم في الغرفة
        member = ChatMember.query.filter_by(room_id=room_id, user_id=user_id).first()
        if not member:
            emit('error', {'message': 'ليس لديك صلاحية للوصول إلى هذه الغرفة'})
            return
        
        # الانضمام إلى الغرفة
        join_room(str(room_id))
        emit('joined_room', {'room_id': room_id, 'message': 'تم الانضمام إلى الغرفة'})
        
        # إشعار الأعضاء الآخرين
        user = User.query.get(user_id)
        emit('user_joined', {
            'user_id': user_id,
            'username': user.username,
            'message': f'{user.username} انضم إلى الغرفة'
        }, room=str(room_id), include_self=False)
        
    except Exception as e:
        emit('error', {'message': f'خطأ في الانضمام إلى الغرفة: {str(e)}'})

@socketio.on('leave_room')
def handle_leave_room(data):
    """مغادرة غرفة دردشة"""
    try:
        if request.sid not in connected_users:
            emit('error', {'message': 'غير مصرح لك'})
            return
        
        user_id = connected_users[request.sid]['user_id']
        room_id = data.get('room_id')
        
        if not room_id:
            emit('error', {'message': 'معرف الغرفة مطلوب'})
            return
        
        # مغادرة الغرفة
        leave_room(str(room_id))
        emit('left_room', {'room_id': room_id, 'message': 'تم مغادرة الغرفة'})
        
        # إشعار الأعضاء الآخرين
        user = User.query.get(user_id)
        emit('user_left', {
            'user_id': user_id,
            'username': user.username,
            'message': f'{user.username} غادر الغرفة'
        }, room=str(room_id), include_self=False)
        
    except Exception as e:
        emit('error', {'message': f'خطأ في مغادرة الغرفة: {str(e)}'})

@socketio.on('send_message')
def handle_send_message(data):
    """إرسال رسالة فورية"""
    try:
        if request.sid not in connected_users:
            emit('error', {'message': 'غير مصرح لك'})
            return
        
        user_id = connected_users[request.sid]['user_id']
        room_id = data.get('room_id')
        content = data.get('content', '').strip()
        message_type = data.get('message_type', 'text')
        file_url = data.get('file_url')
        reply_to = data.get('reply_to')
        
        if not room_id or not content:
            emit('error', {'message': 'معرف الغرفة ومحتوى الرسالة مطلوبان'})
            return
        
        # التحقق من عضوية المستخدم في الغرفة
        member = ChatMember.query.filter_by(room_id=room_id, user_id=user_id).first()
        if not member:
            emit('error', {'message': 'ليس لديك صلاحية للإرسال في هذه الغرفة'})
            return
        
        # التحقق من الرسالة المرد عليها إذا كانت موجودة
        if reply_to:
            parent_message = Message.query.filter_by(id=reply_to, room_id=room_id).first()
            if not parent_message:
                emit('error', {'message': 'الرسالة المرد عليها غير موجودة'})
                return
        
        # إنشاء الرسالة
        message = Message(
            room_id=room_id,
            sender_id=user_id,
            content=content,
            message_type=message_type,
            file_url=file_url,
            reply_to=reply_to
        )
        
        db.session.add(message)
        db.session.commit()
        
        # إرسال الرسالة لجميع أعضاء الغرفة
        message_data = message.to_dict()
        emit('new_message', message_data, room=str(room_id))
        
        # إرسال تأكيد للمرسل
        emit('message_sent', {
            'message_id': message.id,
            'status': 'sent',
            'timestamp': message.created_at.isoformat()
        })
        
    except Exception as e:
        db.session.rollback()
        emit('error', {'message': f'خطأ في إرسال الرسالة: {str(e)}'})

@socketio.on('typing')
def handle_typing(data):
    """التعامل مع حالة الكتابة"""
    try:
        if request.sid not in connected_users:
            return
        
        user_id = connected_users[request.sid]['user_id']
        room_id = data.get('room_id')
        is_typing = data.get('is_typing', False)
        
        if not room_id:
            return
        
        # التحقق من عضوية المستخدم في الغرفة
        member = ChatMember.query.filter_by(room_id=room_id, user_id=user_id).first()
        if not member:
            return
        
        user = User.query.get(user_id)
        
        # إرسال حالة الكتابة للأعضاء الآخرين
        emit('user_typing', {
            'user_id': user_id,
            'username': user.username,
            'is_typing': is_typing
        }, room=str(room_id), include_self=False)
        
    except Exception as e:
        print(f"Typing error: {str(e)}")

@socketio.on('get_online_users')
def handle_get_online_users(data):
    """الحصول على المستخدمين المتصلين في غرفة"""
    try:
        if request.sid not in connected_users:
            emit('error', {'message': 'غير مصرح لك'})
            return
        
        room_id = data.get('room_id')
        if not room_id:
            emit('error', {'message': 'معرف الغرفة مطلوب'})
            return
        
        # الحصول على أعضاء الغرفة المتصلين
        online_users = []
        for sid, user_info in connected_users.items():
            # التحقق من عضوية المستخدم في الغرفة
            member = ChatMember.query.filter_by(room_id=room_id, user_id=user_info['user_id']).first()
            if member:
                user = User.query.get(user_info['user_id'])
                online_users.append({
                    'user_id': user.id,
                    'username': user.username,
                    'display_name': user.display_name or user.username,
                    'avatar_url': user.avatar_url
                })
        
        emit('online_users', {'room_id': room_id, 'users': online_users})
        
    except Exception as e:
        emit('error', {'message': f'خطأ في جلب المستخدمين المتصلين: {str(e)}'})

# دالة مساعدة لإرسال إشعار لمستخدم معين
def send_notification_to_user(user_id, notification_data):
    """إرسال إشعار لمستخدم معين"""
    try:
        for sid, user_info in connected_users.items():
            if user_info['user_id'] == user_id:
                socketio.emit('notification', notification_data, room=sid)
                break
    except Exception as e:
        print(f"Notification error: {str(e)}")

# دالة مساعدة لإرسال إشعار لجميع المستخدمين
def broadcast_notification(notification_data):
    """إرسال إشعار لجميع المستخدمين المتصلين"""
    try:
        socketio.emit('broadcast_notification', notification_data)
    except Exception as e:
        print(f"Broadcast notification error: {str(e)}")

