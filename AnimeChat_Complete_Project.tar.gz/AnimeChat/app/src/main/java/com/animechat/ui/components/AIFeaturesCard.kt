package com.animechat.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.animechat.data.ai.AnimeRecommendation
import com.animechat.ui.theme.AnimeChatColors

@Composable
fun AIFeaturesCard(
    onAnimeRecommendations: () -> Unit,
    onSmartReplies: () -> Unit,
    onChatSummary: () -> Unit,
    onConversationStarters: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AnimeChatColors.SecondaryBackground
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "AI Features",
                    tint = AnimeChatColors.PurpleAccent,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(8.dp))
                
                Text(
                    text = "ميزات الذكاء الاصطناعي",
                    style = MaterialTheme.typography.titleMedium,
                    color = AnimeChatColors.PrimaryText,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 4.dp)
            ) {
                item {
                    AIFeatureButton(
                        icon = Icons.Default.Recommend,
                        title = "توصيات الأنمي",
                        description = "احصل على توصيات شخصية",
                        onClick = onAnimeRecommendations
                    )
                }
                
                item {
                    AIFeatureButton(
                        icon = Icons.Default.QuestionAnswer,
                        title = "ردود ذكية",
                        description = "اقتراحات للرد السريع",
                        onClick = onSmartReplies
                    )
                }
                
                item {
                    AIFeatureButton(
                        icon = Icons.Default.Summarize,
                        title = "ملخص المحادثة",
                        description = "تلخيص النقاط المهمة",
                        onClick = onChatSummary
                    )
                }
                
                item {
                    AIFeatureButton(
                        icon = Icons.Default.ChatBubble,
                        title = "بدء محادثة",
                        description = "مواضيع للنقاش",
                        onClick = onConversationStarters
                    )
                }
            }
        }
    }
}

@Composable
private fun AIFeatureButton(
    icon: ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .width(140.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = AnimeChatColors.SurfaceBackground
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = AnimeChatColors.LightBlueAccent,
                modifier = Modifier.size(32.dp)
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = AnimeChatColors.PrimaryText,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = AnimeChatColors.SecondaryText,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun AnimeRecommendationsDialog(
    recommendations: List<AnimeRecommendation>,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Recommend,
                    contentDescription = "Recommendations",
                    tint = AnimeChatColors.PurpleAccent
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "توصيات الأنمي",
                    color = AnimeChatColors.PrimaryText
                )
            }
        },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(recommendations) { recommendation ->
                    AnimeRecommendationCard(recommendation = recommendation)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = AnimeChatColors.PurpleAccent
                )
            ) {
                Text("إغلاق")
            }
        },
        containerColor = AnimeChatColors.SecondaryBackground,
        textContentColor = AnimeChatColors.PrimaryText
    )
}

@Composable
private fun AnimeRecommendationCard(
    recommendation: AnimeRecommendation,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = AnimeChatColors.SurfaceBackground
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = recommendation.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = AnimeChatColors.PrimaryText,
                    fontWeight = FontWeight.Bold
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rating",
                        tint = AnimeChatColors.WarningOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = recommendation.rating.toString(),
                        style = MaterialTheme.typography.bodySmall,
                        color = AnimeChatColors.SecondaryText
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = recommendation.genre,
                style = MaterialTheme.typography.bodySmall,
                color = AnimeChatColors.LightBlueAccent
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = recommendation.description,
                style = MaterialTheme.typography.bodySmall,
                color = AnimeChatColors.SecondaryText
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "السبب: ${recommendation.reason}",
                style = MaterialTheme.typography.bodySmall,
                color = AnimeChatColors.PurpleAccent,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun SmartRepliesChips(
    suggestions: List<String>,
    onSuggestionClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(horizontal = 16.dp)
    ) {
        items(suggestions) { suggestion ->
            SuggestionChip(
                onClick = { onSuggestionClick(suggestion) },
                label = {
                    Text(
                        text = suggestion,
                        style = MaterialTheme.typography.bodySmall,
                        color = AnimeChatColors.PrimaryText
                    )
                },
                colors = SuggestionChipDefaults.suggestionChipColors(
                    containerColor = AnimeChatColors.SurfaceBackground,
                    labelColor = AnimeChatColors.PrimaryText
                ),
                border = SuggestionChipDefaults.suggestionChipBorder(
                    borderColor = AnimeChatColors.PurpleAccent
                )
            )
        }
    }
}

@Composable
fun ConversationStartersDialog(
    starters: List<String>,
    onStarterClick: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ChatBubble,
                    contentDescription = "Conversation Starters",
                    tint = AnimeChatColors.LightBlueAccent
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مواضيع للنقاش",
                    color = AnimeChatColors.PrimaryText
                )
            }
        },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(starters) { starter ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onStarterClick(starter) },
                        colors = CardDefaults.cardColors(
                            containerColor = AnimeChatColors.SurfaceBackground
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = starter,
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = AnimeChatColors.PrimaryText
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = AnimeChatColors.LightBlueAccent
                )
            ) {
                Text("إغلاق")
            }
        },
        containerColor = AnimeChatColors.SecondaryBackground,
        textContentColor = AnimeChatColors.PrimaryText
    )
}

