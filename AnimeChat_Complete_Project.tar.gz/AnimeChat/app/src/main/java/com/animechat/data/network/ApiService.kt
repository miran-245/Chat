package com.animechat.data.network

import com.animechat.data.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    
    // Authentication endpoints
    @POST("auth/register")
    suspend fun register(@Body request: RegisterRequest): Response<AuthResponse>
    
    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<AuthResponse>
    
    @GET("auth/profile")
    suspend fun getProfile(@Header("Authorization") token: String): Response<ApiResponse<User>>
    
    @PUT("auth/profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body request: UpdateProfileRequest
    ): Response<ApiResponse<User>>
    
    @POST("auth/change-password")
    suspend fun changePassword(
        @Header("Authorization") token: String,
        @Body request: ChangePasswordRequest
    ): Response<ApiResponse<String>>
    
    // Chat endpoints
    @GET("chat/rooms")
    suspend fun getChatRooms(@Header("Authorization") token: String): Response<ChatRoomsResponse>
    
    @POST("chat/rooms")
    suspend fun createChatRoom(
        @Header("Authorization") token: String,
        @Body request: CreateRoomRequest
    ): Response<ApiResponse<ChatRoom>>
    
    @POST("chat/rooms/{roomId}/join")
    suspend fun joinChatRoom(
        @Header("Authorization") token: String,
        @Path("roomId") roomId: Int
    ): Response<ApiResponse<String>>
    
    @GET("chat/rooms/{roomId}/messages")
    suspend fun getRoomMessages(
        @Header("Authorization") token: String,
        @Path("roomId") roomId: Int,
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 50
    ): Response<MessagesResponse>
    
    @POST("chat/rooms/{roomId}/messages")
    suspend fun sendMessage(
        @Header("Authorization") token: String,
        @Path("roomId") roomId: Int,
        @Body request: SendMessageRequest
    ): Response<ApiResponse<Message>>
    
    @DELETE("chat/messages/{messageId}")
    suspend fun deleteMessage(
        @Header("Authorization") token: String,
        @Path("messageId") messageId: Int
    ): Response<ApiResponse<String>>
    
    @POST("chat/users/{userId}/block")
    suspend fun blockUser(
        @Header("Authorization") token: String,
        @Path("userId") userId: Int,
        @Body request: BlockUserRequest
    ): Response<ApiResponse<String>>
    
    @POST("chat/users/{userId}/unblock")
    suspend fun unblockUser(
        @Header("Authorization") token: String,
        @Path("userId") userId: Int
    ): Response<ApiResponse<String>>
    
    @GET("chat/blocked-users")
    suspend fun getBlockedUsers(@Header("Authorization") token: String): Response<ApiResponse<List<User>>>
    
    // Admin endpoints
    @GET("admin/dashboard")
    suspend fun getDashboardStats(@Header("Authorization") token: String): Response<ApiResponse<DashboardStats>>
    
    @GET("admin/users")
    suspend fun getAllUsers(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 20,
        @Query("search") search: String? = null
    ): Response<ApiResponse<UsersResponse>>
    
    @POST("admin/users/{userId}/toggle-status")
    suspend fun toggleUserStatus(
        @Header("Authorization") token: String,
        @Path("userId") userId: Int
    ): Response<ApiResponse<String>>
    
    @POST("admin/users/{userId}/make-admin")
    suspend fun makeUserAdmin(
        @Header("Authorization") token: String,
        @Path("userId") userId: Int
    ): Response<ApiResponse<String>>
    
    @POST("admin/users/{userId}/remove-admin")
    suspend fun removeUserAdmin(
        @Header("Authorization") token: String,
        @Path("userId") userId: Int
    ): Response<ApiResponse<String>>
    
    @GET("admin/rooms")
    suspend fun getAllRooms(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 20
    ): Response<ApiResponse<RoomsResponse>>
    
    @DELETE("admin/rooms/{roomId}")
    suspend fun deleteRoom(
        @Header("Authorization") token: String,
        @Path("roomId") roomId: Int
    ): Response<ApiResponse<String>>
    
    @GET("admin/messages/recent")
    suspend fun getRecentMessages(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("per_page") perPage: Int = 50
    ): Response<MessagesResponse>
    
    @POST("admin/broadcast")
    suspend fun broadcastMessage(
        @Header("Authorization") token: String,
        @Body request: BroadcastRequest
    ): Response<ApiResponse<String>>
}

// Additional data classes for admin endpoints
data class DashboardStats(
    @SerializedName("stats")
    val stats: Stats,
    
    @SerializedName("active_rooms")
    val activeRooms: List<ActiveRoom>
)

data class Stats(
    @SerializedName("total_users")
    val totalUsers: Int,
    
    @SerializedName("active_users")
    val activeUsers: Int,
    
    @SerializedName("total_rooms")
    val totalRooms: Int,
    
    @SerializedName("total_messages")
    val totalMessages: Int,
    
    @SerializedName("new_users_week")
    val newUsersWeek: Int,
    
    @SerializedName("messages_today")
    val messagesToday: Int
)

data class ActiveRoom(
    @SerializedName("room_id")
    val roomId: Int,
    
    @SerializedName("room_name")
    val roomName: String,
    
    @SerializedName("message_count")
    val messageCount: Int
)

data class UsersResponse(
    @SerializedName("users")
    val users: List<User>,
    
    @SerializedName("pagination")
    val pagination: Pagination
)

data class RoomsResponse(
    @SerializedName("rooms")
    val rooms: List<AdminChatRoom>,
    
    @SerializedName("pagination")
    val pagination: Pagination
)

data class AdminChatRoom(
    @SerializedName("id")
    val id: Int,
    
    @SerializedName("name")
    val name: String,
    
    @SerializedName("description")
    val description: String? = null,
    
    @SerializedName("is_private")
    val isPrivate: Boolean = false,
    
    @SerializedName("created_by")
    val createdBy: Int,
    
    @SerializedName("created_at")
    val createdAt: String,
    
    @SerializedName("member_count")
    val memberCount: Int = 0,
    
    @SerializedName("creator")
    val creator: String,
    
    @SerializedName("message_count")
    val messageCount: Int
)

data class BroadcastRequest(
    @SerializedName("title")
    val title: String? = null,
    
    @SerializedName("message")
    val message: String
)

