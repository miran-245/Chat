package com.animechat.data.ai

import android.content.Context
import com.animechat.data.local.PreferencesManager
import com.animechat.data.models.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class AIManager(private val context: Context) {
    
    private val preferencesManager = PreferencesManager(context)
    
    // Multiple AI service providers for redundancy
    private val openAIService: AIService by lazy {
        createAIService("https://api.openai.com/v1/")
    }
    
    private val anthropicService: AIService by lazy {
        createAIService("https://api.anthropic.com/v1/")
    }
    
    private val geminiService: AIService by lazy {
        createAIService("https://generativelanguage.googleapis.com/v1beta/")
    }
    
    private fun createAIService(baseUrl: String): AIService {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        
        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
        
        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        
        return retrofit.create(AIService::class.java)
    }
    
    /**
     * Generate anime recommendations based on user preferences
     */
    suspend fun getAnimeRecommendations(
        userPreferences: String,
        chatHistory: List<String>? = null,
        favoriteGenres: List<String>? = null
    ): Result<AnimeRecommendationResponse> = withContext(Dispatchers.IO) {
        try {
            val prompt = buildAnimeRecommendationPrompt(userPreferences, chatHistory, favoriteGenres)
            val response = getChatCompletion(prompt, "anime_expert")
            
            // Parse the response and create recommendations
            val recommendations = parseAnimeRecommendations(response)
            Result.success(recommendations)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Generate smart reply suggestions
     */
    suspend fun getSmartReplies(
        context: String,
        lastMessage: String,
        userPersonality: String? = null
    ): Result<SmartReplyResponse> = withContext(Dispatchers.IO) {
        try {
            val prompt = buildSmartReplyPrompt(context, lastMessage, userPersonality)
            val response = getChatCompletion(prompt, "chat_assistant")
            
            val suggestions = parseSmartReplies(response)
            Result.success(suggestions)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Summarize chat conversation
     */
    suspend fun summarizeChat(
        messages: List<String>,
        maxLength: Int = 200
    ): Result<ChatSummaryResponse> = withContext(Dispatchers.IO) {
        try {
            val prompt = buildChatSummaryPrompt(messages, maxLength)
            val response = getChatCompletion(prompt, "summarizer")
            
            val summary = parseChatSummary(response)
            Result.success(summary)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Moderate content for inappropriate material
     */
    suspend fun moderateContent(
        content: String,
        context: String? = null
    ): Result<ContentModerationResponse> = withContext(Dispatchers.IO) {
        try {
            val prompt = buildModerationPrompt(content, context)
            val response = getChatCompletion(prompt, "moderator")
            
            val moderation = parseContentModeration(response)
            Result.success(moderation)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Generate conversation starters based on anime topics
     */
    suspend fun generateConversationStarters(
        topic: String = "anime"
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val prompt = buildConversationStarterPrompt(topic)
            val response = getChatCompletion(prompt, "conversation_starter")
            
            val starters = parseConversationStarters(response)
            Result.success(starters)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Translate messages to different languages
     */
    suspend fun translateMessage(
        message: String,
        targetLanguage: String = "ar"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val prompt = buildTranslationPrompt(message, targetLanguage)
            val response = getChatCompletion(prompt, "translator")
            
            Result.success(response.trim())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    /**
     * Core function to get chat completion from AI service
     */
    private suspend fun getChatCompletion(
        prompt: String,
        role: String = "assistant"
    ): String {
        val messages = listOf(
            ChatMessage("system", getSystemPrompt(role)),
            ChatMessage("user", prompt)
        )
        
        val request = ChatCompletionRequest(
            model = "gpt-3.5-turbo",
            messages = messages,
            maxTokens = 300,
            temperature = 0.7
        )
        
        // Try multiple providers for redundancy
        val providers = listOf(
            { openAIService.getChatCompletion("Bearer YOUR_OPENAI_API_KEY", request) },
            { anthropicService.getChatCompletion("Bearer YOUR_ANTHROPIC_API_KEY", request) },
            { geminiService.getChatCompletion("Bearer YOUR_GEMINI_API_KEY", request) }
        )
        
        for (provider in providers) {
            try {
                val response = provider()
                if (response.isSuccessful && response.body() != null) {
                    return response.body()!!.choices.firstOrNull()?.message?.content ?: ""
                }
            } catch (e: Exception) {
                // Continue to next provider
                continue
            }
        }
        
        throw Exception("All AI providers failed")
    }
    
    private fun getSystemPrompt(role: String): String {
        return when (role) {
            "anime_expert" -> """
                أنت خبير في الأنمي والمانجا. مهمتك هي تقديم توصيات شخصية ودقيقة للأنمي بناءً على تفضيلات المستخدم.
                قدم توصيات متنوعة تشمل أنميات مشهورة وأخرى أقل شهرة ولكنها عالية الجودة.
                اشرح سبب كل توصية بوضوح.
            """.trimIndent()
            
            "chat_assistant" -> """
                أنت مساعد ذكي للدردشة في تطبيق خاص بمحبي الأنمي. 
                مهمتك هي اقتراح ردود مناسبة وودودة تساعد في استمرار المحادثة.
                كن مهذباً ومتفهماً واستخدم مصطلحات الأنمي عند الحاجة.
            """.trimIndent()
            
            "summarizer" -> """
                أنت خبير في تلخيص المحادثات. قم بتلخيص المحادثات بشكل موجز ومفيد،
                مع التركيز على النقاط الرئيسية والمواضيع المهمة.
            """.trimIndent()
            
            "moderator" -> """
                أنت مشرف محتوى ذكي. مهمتك هي تحديد المحتوى غير المناسب أو المؤذي.
                كن دقيقاً ومنصفاً في تقييمك، مع مراعاة السياق الثقافي.
            """.trimIndent()
            
            "conversation_starter" -> """
                أنت خبير في بدء المحادثات حول الأنمي. اقترح مواضيع شيقة ومثيرة للاهتمام
                تساعد الأشخاص على بدء محادثات ممتعة حول الأنمي والمانجا.
            """.trimIndent()
            
            "translator" -> """
                أنت مترجم محترف. قم بترجمة النصوص بدقة مع الحفاظ على المعنى والسياق.
                انتبه للمصطلحات الخاصة بالأنمي والثقافة اليابانية.
            """.trimIndent()
            
            else -> "أنت مساعد ذكي ومفيد."
        }
    }
    
    // Helper functions to build prompts
    private fun buildAnimeRecommendationPrompt(
        userPreferences: String,
        chatHistory: List<String>?,
        favoriteGenres: List<String>?
    ): String {
        val prompt = StringBuilder()
        prompt.append("بناءً على التفضيلات التالية، اقترح 5 أنميات مناسبة:\n\n")
        prompt.append("تفضيلات المستخدم: $userPreferences\n")
        
        favoriteGenres?.let {
            prompt.append("الأنواع المفضلة: ${it.joinToString(", ")}\n")
        }
        
        chatHistory?.let {
            prompt.append("سياق المحادثة: ${it.takeLast(5).joinToString(" | ")}\n")
        }
        
        prompt.append("\nقدم التوصيات في صيغة JSON مع العناصر التالية لكل أنمي:")
        prompt.append("title, genre, rating, description, reason")
        
        return prompt.toString()
    }
    
    private fun buildSmartReplyPrompt(
        context: String,
        lastMessage: String,
        userPersonality: String?
    ): String {
        val prompt = StringBuilder()
        prompt.append("اقترح 3 ردود مناسبة للرسالة التالية:\n\n")
        prompt.append("السياق: $context\n")
        prompt.append("آخر رسالة: $lastMessage\n")
        
        userPersonality?.let {
            prompt.append("شخصية المستخدم: $it\n")
        }
        
        prompt.append("\nاجعل الردود متنوعة (رسمي، ودود، مرح) ومناسبة للسياق.")
        
        return prompt.toString()
    }
    
    private fun buildChatSummaryPrompt(messages: List<String>, maxLength: Int): String {
        val prompt = StringBuilder()
        prompt.append("لخص المحادثة التالية في $maxLength كلمة أو أقل:\n\n")
        prompt.append(messages.joinToString("\n"))
        prompt.append("\n\nقدم ملخصاً يتضمن النقاط الرئيسية والمواضيع المهمة.")
        
        return prompt.toString()
    }
    
    private fun buildModerationPrompt(content: String, context: String?): String {
        val prompt = StringBuilder()
        prompt.append("قيم المحتوى التالي من ناحية الملاءمة والأمان:\n\n")
        prompt.append("المحتوى: $content\n")
        
        context?.let {
            prompt.append("السياق: $it\n")
        }
        
        prompt.append("\nحدد ما إذا كان المحتوى مناسباً أم لا، مع تقديم تفسير.")
        
        return prompt.toString()
    }
    
    private fun buildConversationStarterPrompt(topic: String): String {
        return """
            اقترح 5 مواضيع محادثة شيقة حول $topic.
            اجعل المواضيع متنوعة ومثيرة للاهتمام وتشجع على النقاش.
            قدم كل موضوع كسؤال أو عبارة تحفز الآخرين على المشاركة.
        """.trimIndent()
    }
    
    private fun buildTranslationPrompt(message: String, targetLanguage: String): String {
        return "ترجم النص التالي إلى $targetLanguage مع الحفاظ على المعنى والسياق:\n\n$message"
    }
    
    // Parsing functions (simplified - in real implementation, use proper JSON parsing)
    private fun parseAnimeRecommendations(response: String): AnimeRecommendationResponse {
        // Simplified parsing - implement proper JSON parsing
        return AnimeRecommendationResponse(
            recommendations = listOf(
                AnimeRecommendation(
                    title = "Attack on Titan",
                    genre = "Action, Drama",
                    rating = 9.0,
                    description = "أنمي مثير عن البشر والعمالقة",
                    reason = "مناسب لمحبي الأكشن والدراما"
                )
            ),
            explanation = "توصيات مبنية على تفضيلاتك"
        )
    }
    
    private fun parseSmartReplies(response: String): SmartReplyResponse {
        val suggestions = response.split("\n").filter { it.isNotBlank() }.take(3)
        return SmartReplyResponse(
            suggestions = suggestions,
            confidence = 0.8
        )
    }
    
    private fun parseChatSummary(response: String): ChatSummaryResponse {
        return ChatSummaryResponse(
            summary = response,
            keyTopics = listOf("أنمي", "توصيات", "مناقشة"),
            sentiment = "إيجابي"
        )
    }
    
    private fun parseContentModeration(response: String): ContentModerationResponse {
        val isAppropriate = !response.contains("غير مناسب", ignoreCase = true)
        return ContentModerationResponse(
            isAppropriate = isAppropriate,
            confidence = 0.9,
            categories = listOf("عام"),
            suggestedAction = if (isAppropriate) "السماح" else "المراجعة"
        )
    }
    
    private fun parseConversationStarters(response: String): List<String> {
        return response.split("\n").filter { it.isNotBlank() }.take(5)
    }
}

