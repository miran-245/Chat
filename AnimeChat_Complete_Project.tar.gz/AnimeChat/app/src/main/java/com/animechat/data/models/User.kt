package com.animechat.data.models

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("id")
    val id: Int,
    
    @SerializedName("username")
    val username: String,
    
    @SerializedName("email")
    val email: String? = null,
    
    @SerializedName("display_name")
    val displayName: String,
    
    @SerializedName("bio")
    val bio: String? = null,
    
    @SerializedName("avatar_url")
    val avatarUrl: String? = null,
    
    @SerializedName("favorite_anime")
    val favoriteAnime: String? = null,
    
    @SerializedName("is_admin")
    val isAdmin: Boolean = false,
    
    @SerializedName("is_active")
    val isActive: Boolean = true,
    
    @SerializedName("last_seen")
    val lastSeen: String? = null,
    
    @SerializedName("created_at")
    val createdAt: String
)

data class LoginRequest(
    @SerializedName("username")
    val username: String,
    
    @SerializedName("password")
    val password: String
)

data class RegisterRequest(
    @SerializedName("username")
    val username: String,
    
    @SerializedName("email")
    val email: String,
    
    @SerializedName("password")
    val password: String,
    
    @SerializedName("display_name")
    val displayName: String? = null
)

data class AuthResponse(
    @SerializedName("message")
    val message: String,
    
    @SerializedName("access_token")
    val accessToken: String,
    
    @SerializedName("user")
    val user: User
)

data class UpdateProfileRequest(
    @SerializedName("display_name")
    val displayName: String? = null,
    
    @SerializedName("bio")
    val bio: String? = null,
    
    @SerializedName("avatar_url")
    val avatarUrl: String? = null,
    
    @SerializedName("favorite_anime")
    val favoriteAnime: List<String>? = null
)

data class ChangePasswordRequest(
    @SerializedName("current_password")
    val currentPassword: String,
    
    @SerializedName("new_password")
    val newPassword: String
)

