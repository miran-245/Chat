package com.animechat

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.animechat.data.local.PreferencesManager
import com.animechat.ui.auth.AuthActivity
import com.animechat.ui.chat.ChatListScreen
import com.animechat.ui.theme.AnimeChatTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var preferencesManager: PreferencesManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        preferencesManager = PreferencesManager(this)
        
        // التحقق من حالة تسجيل الدخول
        lifecycleScope.launch {
            val isLoggedIn = preferencesManager.isLoggedIn()
            if (!isLoggedIn) {
                // الانتقال إلى شاشة تسجيل الدخول
                startActivity(Intent(this@MainActivity, AuthActivity::class.java))
                finish()
                return@launch
            }
            
            // إعداد الواجهة الرئيسية
            setContent {
                AnimeChatTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        MainScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    
    // هنا سيتم إضافة التنقل بين الشاشات المختلفة
    when (selectedTab) {
        0 -> ChatListScreen()
        // يمكن إضافة المزيد من الشاشات هنا
    }
}

