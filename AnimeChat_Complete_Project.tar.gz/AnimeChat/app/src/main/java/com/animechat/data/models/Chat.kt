package com.animechat.data.models

import com.google.gson.annotations.SerializedName

data class ChatRoom(
    @SerializedName("id")
    val id: Int,
    
    @SerializedName("name")
    val name: String,
    
    @SerializedName("description")
    val description: String? = null,
    
    @SerializedName("is_private")
    val isPrivate: Boolean = false,
    
    @SerializedName("created_by")
    val createdBy: Int,
    
    @SerializedName("created_at")
    val createdAt: String,
    
    @SerializedName("member_count")
    val memberCount: Int = 0,
    
    @SerializedName("last_message")
    val lastMessage: Message? = null
)

data class Message(
    @SerializedName("id")
    val id: Int,
    
    @SerializedName("room_id")
    val roomId: Int,
    
    @SerializedName("sender_id")
    val senderId: Int,
    
    @SerializedName("sender_username")
    val senderUsername: String? = null,
    
    @SerializedName("content")
    val content: String,
    
    @SerializedName("message_type")
    val messageType: String = "text", // text, image, video, file, announcement
    
    @SerializedName("file_url")
    val fileUrl: String? = null,
    
    @SerializedName("reply_to")
    val replyTo: Int? = null,
    
    @SerializedName("is_deleted")
    val isDeleted: Boolean = false,
    
    @SerializedName("created_at")
    val createdAt: String,
    
    @SerializedName("updated_at")
    val updatedAt: String
)

data class ChatMember(
    @SerializedName("id")
    val id: Int,
    
    @SerializedName("room_id")
    val roomId: Int,
    
    @SerializedName("user_id")
    val userId: Int,
    
    @SerializedName("joined_at")
    val joinedAt: String,
    
    @SerializedName("is_admin")
    val isAdmin: Boolean = false
)

data class CreateRoomRequest(
    @SerializedName("name")
    val name: String,
    
    @SerializedName("description")
    val description: String? = null,
    
    @SerializedName("is_private")
    val isPrivate: Boolean = false
)

data class SendMessageRequest(
    @SerializedName("content")
    val content: String,
    
    @SerializedName("message_type")
    val messageType: String = "text",
    
    @SerializedName("file_url")
    val fileUrl: String? = null,
    
    @SerializedName("reply_to")
    val replyTo: Int? = null
)

data class BlockUserRequest(
    @SerializedName("reason")
    val reason: String? = null
)

data class ChatRoomsResponse(
    @SerializedName("rooms")
    val rooms: List<ChatRoom>
)

data class MessagesResponse(
    @SerializedName("messages")
    val messages: List<Message>,
    
    @SerializedName("pagination")
    val pagination: Pagination
)

data class Pagination(
    @SerializedName("page")
    val page: Int,
    
    @SerializedName("pages")
    val pages: Int,
    
    @SerializedName("per_page")
    val perPage: Int,
    
    @SerializedName("total")
    val total: Int,
    
    @SerializedName("has_next")
    val hasNext: Boolean,
    
    @SerializedName("has_prev")
    val hasPrev: Boolean
)

data class ApiResponse<T>(
    @SerializedName("message")
    val message: String? = null,
    
    @SerializedName("data")
    val data: T? = null,
    
    @SerializedName("error")
    val error: String? = null
)

// WebSocket Events
data class SocketMessage(
    @SerializedName("room_id")
    val roomId: Int,
    
    @SerializedName("content")
    val content: String,
    
    @SerializedName("message_type")
    val messageType: String = "text",
    
    @SerializedName("file_url")
    val fileUrl: String? = null,
    
    @SerializedName("reply_to")
    val replyTo: Int? = null
)

data class TypingEvent(
    @SerializedName("room_id")
    val roomId: Int,
    
    @SerializedName("is_typing")
    val isTyping: Boolean
)

data class JoinRoomEvent(
    @SerializedName("room_id")
    val roomId: Int
)

data class UserTypingEvent(
    @SerializedName("user_id")
    val userId: Int,
    
    @SerializedName("username")
    val username: String,
    
    @SerializedName("is_typing")
    val isTyping: Boolean
)

data class OnlineUsersResponse(
    @SerializedName("room_id")
    val roomId: Int,
    
    @SerializedName("users")
    val users: List<OnlineUser>
)

data class OnlineUser(
    @SerializedName("user_id")
    val userId: Int,
    
    @SerializedName("username")
    val username: String,
    
    @SerializedName("display_name")
    val displayName: String,
    
    @SerializedName("avatar_url")
    val avatarUrl: String?
)

