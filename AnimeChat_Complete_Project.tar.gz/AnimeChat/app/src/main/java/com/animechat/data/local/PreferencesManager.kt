package com.animechat.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "anime_chat_prefs")

class PreferencesManager(private val context: Context) {
    
    companion object {
        private val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
        private val ACCESS_TOKEN = stringPreferencesKey("access_token")
        private val USER_ID = stringPreferencesKey("user_id")
        private val USERNAME = stringPreferencesKey("username")
        private val EMAIL = stringPreferencesKey("email")
        private val DISPLAY_NAME = stringPreferencesKey("display_name")
        private val AVATAR_URL = stringPreferencesKey("avatar_url")
        private val IS_ADMIN = booleanPreferencesKey("is_admin")
        private val SERVER_URL = stringPreferencesKey("server_url")
    }
    
    // تسجيل الدخول
    suspend fun saveLoginData(
        accessToken: String,
        userId: String,
        username: String,
        email: String,
        displayName: String?,
        avatarUrl: String?,
        isAdmin: Boolean
    ) {
        context.dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = true
            preferences[ACCESS_TOKEN] = accessToken
            preferences[USER_ID] = userId
            preferences[USERNAME] = username
            preferences[EMAIL] = email
            preferences[DISPLAY_NAME] = displayName ?: username
            preferences[AVATAR_URL] = avatarUrl ?: ""
            preferences[IS_ADMIN] = isAdmin
        }
    }
    
    // تسجيل الخروج
    suspend fun logout() {
        context.dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = false
            preferences.remove(ACCESS_TOKEN)
            preferences.remove(USER_ID)
            preferences.remove(USERNAME)
            preferences.remove(EMAIL)
            preferences.remove(DISPLAY_NAME)
            preferences.remove(AVATAR_URL)
            preferences.remove(IS_ADMIN)
        }
    }
    
    // التحقق من حالة تسجيل الدخول
    suspend fun isLoggedIn(): Boolean {
        return context.dataStore.data.first()[IS_LOGGED_IN] ?: false
    }
    
    // الحصول على رمز الوصول
    suspend fun getAccessToken(): String? {
        return context.dataStore.data.first()[ACCESS_TOKEN]
    }
    
    // الحصول على معرف المستخدم
    suspend fun getUserId(): String? {
        return context.dataStore.data.first()[USER_ID]
    }
    
    // الحصول على اسم المستخدم
    suspend fun getUsername(): String? {
        return context.dataStore.data.first()[USERNAME]
    }
    
    // الحصول على البريد الإلكتروني
    suspend fun getEmail(): String? {
        return context.dataStore.data.first()[EMAIL]
    }
    
    // الحصول على الاسم المعروض
    suspend fun getDisplayName(): String? {
        return context.dataStore.data.first()[DISPLAY_NAME]
    }
    
    // الحصول على رابط الصورة الشخصية
    suspend fun getAvatarUrl(): String? {
        return context.dataStore.data.first()[AVATAR_URL]
    }
    
    // التحقق من صلاحيات المدير
    suspend fun isAdmin(): Boolean {
        return context.dataStore.data.first()[IS_ADMIN] ?: false
    }
    
    // حفظ رابط الخادم
    suspend fun saveServerUrl(url: String) {
        context.dataStore.edit { preferences ->
            preferences[SERVER_URL] = url
        }
    }
    
    // الحصول على رابط الخادم
    suspend fun getServerUrl(): String {
        return context.dataStore.data.first()[SERVER_URL] ?: "http://10.0.2.2:5000" // Default for Android emulator
    }
    
    // Flow للاستماع لتغييرات حالة تسجيل الدخول
    val isLoggedInFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[IS_LOGGED_IN] ?: false
    }
    
    // Flow للاستماع لتغييرات بيانات المستخدم
    val userDataFlow: Flow<UserData> = context.dataStore.data.map { preferences ->
        UserData(
            userId = preferences[USER_ID] ?: "",
            username = preferences[USERNAME] ?: "",
            email = preferences[EMAIL] ?: "",
            displayName = preferences[DISPLAY_NAME] ?: "",
            avatarUrl = preferences[AVATAR_URL] ?: "",
            isAdmin = preferences[IS_ADMIN] ?: false
        )
    }
}

data class UserData(
    val userId: String,
    val username: String,
    val email: String,
    val displayName: String,
    val avatarUrl: String,
    val isAdmin: Boolean
)

