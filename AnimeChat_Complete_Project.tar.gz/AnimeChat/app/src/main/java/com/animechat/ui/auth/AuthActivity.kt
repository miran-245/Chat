package com.animechat.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.animechat.MainActivity
import com.animechat.data.local.PreferencesManager
import com.animechat.ui.theme.AnimeChatTheme
import kotlinx.coroutines.launch

class AuthActivity : ComponentActivity() {
    private lateinit var preferencesManager: PreferencesManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        preferencesManager = PreferencesManager(this)
        
        // التحقق من حالة تسجيل الدخول
        lifecycleScope.launch {
            val isLoggedIn = preferencesManager.isLoggedIn()
            if (isLoggedIn) {
                // الانتقال إلى الشاشة الرئيسية
                startActivity(Intent(this@AuthActivity, MainActivity::class.java))
                finish()
                return@launch
            }
        }
        
        setContent {
            AnimeChatTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AuthScreen(
                        onLoginSuccess = { accessToken, user ->
                            lifecycleScope.launch {
                                preferencesManager.saveLoginData(
                                    accessToken = accessToken,
                                    userId = user.id.toString(),
                                    username = user.username,
                                    email = user.email ?: "",
                                    displayName = user.displayName,
                                    avatarUrl = user.avatarUrl,
                                    isAdmin = user.isAdmin
                                )
                                
                                startActivity(Intent(this@AuthActivity, MainActivity::class.java))
                                finish()
                            }
                        }
                    )
                }
            }
        }
    }
}

