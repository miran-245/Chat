package com.animechat.data.ai

import com.animechat.data.models.Message
import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.*

interface AIService {
    
    @POST("chat/completions")
    suspend fun getChatCompletion(
        @Header("Authorization") apiKey: String,
        @Body request: ChatCompletionRequest
    ): Response<ChatCompletionResponse>
    
    @POST("embeddings")
    suspend fun getEmbeddings(
        @Header("Authorization") apiKey: String,
        @Body request: EmbeddingRequest
    ): Response<EmbeddingResponse>
}

// Data classes for AI API requests and responses
data class ChatCompletionRequest(
    @SerializedName("model")
    val model: String = "gpt-3.5-turbo",
    
    @SerializedName("messages")
    val messages: List<ChatMessage>,
    
    @SerializedName("max_tokens")
    val maxTokens: Int = 150,
    
    @SerializedName("temperature")
    val temperature: Double = 0.7,
    
    @SerializedName("stream")
    val stream: Boolean = false
)

data class ChatMessage(
    @SerializedName("role")
    val role: String, // "system", "user", "assistant"
    
    @SerializedName("content")
    val content: String
)

data class ChatCompletionResponse(
    @SerializedName("id")
    val id: String,
    
    @SerializedName("object")
    val objectType: String,
    
    @SerializedName("created")
    val created: Long,
    
    @SerializedName("model")
    val model: String,
    
    @SerializedName("choices")
    val choices: List<Choice>,
    
    @SerializedName("usage")
    val usage: Usage?
)

data class Choice(
    @SerializedName("index")
    val index: Int,
    
    @SerializedName("message")
    val message: ChatMessage,
    
    @SerializedName("finish_reason")
    val finishReason: String?
)

data class Usage(
    @SerializedName("prompt_tokens")
    val promptTokens: Int,
    
    @SerializedName("completion_tokens")
    val completionTokens: Int,
    
    @SerializedName("total_tokens")
    val totalTokens: Int
)

data class EmbeddingRequest(
    @SerializedName("model")
    val model: String = "text-embedding-ada-002",
    
    @SerializedName("input")
    val input: String
)

data class EmbeddingResponse(
    @SerializedName("object")
    val objectType: String,
    
    @SerializedName("data")
    val data: List<EmbeddingData>,
    
    @SerializedName("model")
    val model: String,
    
    @SerializedName("usage")
    val usage: Usage
)

data class EmbeddingData(
    @SerializedName("object")
    val objectType: String,
    
    @SerializedName("embedding")
    val embedding: List<Double>,
    
    @SerializedName("index")
    val index: Int
)

// AI Features for Anime Chat
data class AnimeRecommendationRequest(
    @SerializedName("user_preferences")
    val userPreferences: String,
    
    @SerializedName("chat_history")
    val chatHistory: List<String>? = null,
    
    @SerializedName("favorite_genres")
    val favoriteGenres: List<String>? = null
)

data class AnimeRecommendationResponse(
    @SerializedName("recommendations")
    val recommendations: List<AnimeRecommendation>,
    
    @SerializedName("explanation")
    val explanation: String
)

data class AnimeRecommendation(
    @SerializedName("title")
    val title: String,
    
    @SerializedName("genre")
    val genre: String,
    
    @SerializedName("rating")
    val rating: Double,
    
    @SerializedName("description")
    val description: String,
    
    @SerializedName("reason")
    val reason: String
)

data class ChatSummaryRequest(
    @SerializedName("messages")
    val messages: List<String>,
    
    @SerializedName("max_length")
    val maxLength: Int = 200
)

data class ChatSummaryResponse(
    @SerializedName("summary")
    val summary: String,
    
    @SerializedName("key_topics")
    val keyTopics: List<String>,
    
    @SerializedName("sentiment")
    val sentiment: String
)

data class SmartReplyRequest(
    @SerializedName("context")
    val context: String,
    
    @SerializedName("last_message")
    val lastMessage: String,
    
    @SerializedName("user_personality")
    val userPersonality: String? = null
)

data class SmartReplyResponse(
    @SerializedName("suggestions")
    val suggestions: List<String>,
    
    @SerializedName("confidence")
    val confidence: Double
)

data class ContentModerationRequest(
    @SerializedName("content")
    val content: String,
    
    @SerializedName("context")
    val context: String? = null
)

data class ContentModerationResponse(
    @SerializedName("is_appropriate")
    val isAppropriate: Boolean,
    
    @SerializedName("confidence")
    val confidence: Double,
    
    @SerializedName("categories")
    val categories: List<String>,
    
    @SerializedName("suggested_action")
    val suggestedAction: String
)

