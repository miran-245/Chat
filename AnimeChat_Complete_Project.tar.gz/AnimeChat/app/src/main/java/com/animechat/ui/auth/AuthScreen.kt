package com.animechat.ui.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.animechat.R
import com.animechat.data.models.User
import com.animechat.ui.theme.AnimeChatColors

@Composable
fun AuthScreen(
    onLoginSuccess: (String, User) -> Unit,
    viewModel: AuthViewModel = viewModel()
) {
    var isLoginMode by remember { mutableStateOf(true) }
    val uiState by viewModel.uiState.collectAsState()
    
    // Handle login success
    LaunchedEffect(uiState.isSuccess, uiState.user, uiState.accessToken) {
        if (uiState.isSuccess && uiState.user != null && uiState.accessToken != null) {
            onLoginSuccess(uiState.accessToken, uiState.user)
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        AnimeChatColors.PrimaryBackground,
                        AnimeChatColors.SecondaryBackground
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Logo and Title
            AppHeader()
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Auth Form Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = AnimeChatColors.SecondaryBackground
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Tab Selector
                    AuthTabSelector(
                        isLoginMode = isLoginMode,
                        onTabChanged = { isLoginMode = it }
                    )
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Auth Form
                    if (isLoginMode) {
                        LoginForm(
                            uiState = uiState,
                            onLogin = viewModel::login
                        )
                    } else {
                        RegisterForm(
                            uiState = uiState,
                            onRegister = viewModel::register
                        )
                    }
                    
                    // Error Message
                    if (uiState.errorMessage != null) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = uiState.errorMessage,
                            color = AnimeChatColors.ErrorRed,
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Footer
            AuthFooter()
        }
        
        // Loading Overlay
        if (uiState.isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AnimeChatColors.PrimaryBackground.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = AnimeChatColors.PurpleAccent
                )
            }
        }
    }
}

@Composable
private fun AppHeader() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Icon/Logo placeholder
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(AnimeChatColors.PurpleAccent),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "AC",
                color = AnimeChatColors.PrimaryText,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineLarge,
            color = AnimeChatColors.PrimaryText,
            fontWeight = FontWeight.Bold
        )
        
        Text(
            text = "دردشة محبي الأنمي",
            style = MaterialTheme.typography.bodyLarge,
            color = AnimeChatColors.SecondaryText,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun AuthTabSelector(
    isLoginMode: Boolean,
    onTabChanged: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(AnimeChatColors.SurfaceBackground),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        TabButton(
            text = stringResource(R.string.login),
            isSelected = isLoginMode,
            onClick = { onTabChanged(true) },
            modifier = Modifier.weight(1f)
        )
        
        TabButton(
            text = stringResource(R.string.register),
            isSelected = !isLoginMode,
            onClick = { onTabChanged(false) },
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun TabButton(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.padding(4.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) AnimeChatColors.PurpleAccent else AnimeChatColors.SurfaceBackground,
            contentColor = if (isSelected) AnimeChatColors.PrimaryText else AnimeChatColors.SecondaryText
        ),
        shape = RoundedCornerShape(6.dp),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = if (isSelected) 4.dp else 0.dp
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun AuthFooter() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "مرحباً بك في عالم الأنمي",
            style = MaterialTheme.typography.bodySmall,
            color = AnimeChatColors.SecondaryText,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "تواصل مع محبي الأنمي من جميع أنحاء العالم",
            style = MaterialTheme.typography.bodySmall,
            color = AnimeChatColors.SecondaryText,
            textAlign = TextAlign.Center
        )
    }
}

