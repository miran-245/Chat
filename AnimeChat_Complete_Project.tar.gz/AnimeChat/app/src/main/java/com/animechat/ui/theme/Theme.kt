package com.animechat.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Dark Theme Colors (الطابع السوداوي)
private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFBB86FC),           // Purple accent
    onPrimary = Color(0xFFFFFFFF),         // White text on purple
    primaryContainer = Color(0xFF3700B3),  // Darker purple
    onPrimaryContainer = Color(0xFFFFFFFF),
    
    secondary = Color(0xFF03DAC6),         // Light blue accent
    onSecondary = Color(0xFF000000),       // Black text on light blue
    secondaryContainer = Color(0xFF018786), // Darker teal
    onSecondaryContainer = Color(0xFFFFFFFF),
    
    tertiary = Color(0xFFCF6679),          // Error red
    onTertiary = Color(0xFFFFFFFF),
    
    background = Color(0xFF1A1A1A),        // Primary dark background
    onBackground = Color(0xFFE0E0E0),      // Light text on dark background
    
    surface = Color(0xFF2C2C2C),           // Secondary background
    onSurface = Color(0xFFE0E0E0),         // Light text on surface
    surfaceVariant = Color(0xFF3A3A3A),    // Surface variant
    onSurfaceVariant = Color(0xFFA0A0A0),  // Secondary text
    
    error = Color(0xFFCF6679),             // Error color
    onError = Color(0xFFFFFFFF),
    
    outline = Color(0xFF404040),           // Border color
    outlineVariant = Color(0xFF2C2C2C),    // Divider color
)

// Light Theme Colors (للمقارنة، لكن التطبيق سيستخدم الطابع المظلم بشكل أساسي)
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF6200EE),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFBB86FC),
    onPrimaryContainer = Color(0xFF000000),
    
    secondary = Color(0xFF03DAC6),
    onSecondary = Color(0xFF000000),
    secondaryContainer = Color(0xFF018786),
    onSecondaryContainer = Color(0xFFFFFFFF),
    
    tertiary = Color(0xFFB00020),
    onTertiary = Color(0xFFFFFFFF),
    
    background = Color(0xFFFFFBFE),
    onBackground = Color(0xFF1C1B1F),
    
    surface = Color(0xFFFFFBFE),
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFE7E0EC),
    onSurfaceVariant = Color(0xFF49454F),
    
    error = Color(0xFFB00020),
    onError = Color(0xFFFFFFFF),
    
    outline = Color(0xFF79747E),
    outlineVariant = Color(0xFFCAC4D0),
)

@Composable
fun AnimeChatTheme(
    darkTheme: Boolean = true, // دائماً استخدام الطابع المظلم
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// ألوان إضافية للاستخدام المباشر
object AnimeChatColors {
    val PurpleAccent = Color(0xFFBB86FC)
    val LightBlueAccent = Color(0xFF03DAC6)
    val ErrorRed = Color(0xFFCF6679)
    val SuccessGreen = Color(0xFF4CAF50)
    val WarningOrange = Color(0xFFFF9800)
    
    val PrimaryBackground = Color(0xFF1A1A1A)
    val SecondaryBackground = Color(0xFF2C2C2C)
    val SurfaceBackground = Color(0xFF3A3A3A)
    
    val PrimaryText = Color(0xFFE0E0E0)
    val SecondaryText = Color(0xFFA0A0A0)
    val DisabledText = Color(0xFF666666)
    
    val SentMessageBg = Color(0xFFBB86FC)
    val ReceivedMessageBg = Color(0xFF404040)
    val SystemMessageBg = Color(0xFF2C2C2C)
    
    val OnlineStatus = Color(0xFF4CAF50)
    val OfflineStatus = Color(0xFF666666)
    val TypingIndicator = Color(0xFF03DAC6)
    
    val BorderColor = Color(0xFF404040)
    val DividerColor = Color(0xFF2C2C2C)
}

