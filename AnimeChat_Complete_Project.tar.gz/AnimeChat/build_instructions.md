# تعليمات بناء تطبيق AnimeChat

## المتطلبات الأساسية

### 1. تثبيت Android Studio
- قم بتحميل وتثبيت Android Studio من الموقع الرسمي
- تأكد من تثبيت Android SDK (API Level 24 أو أحدث)
- قم بتثبيت Android Build Tools

### 2. تثبيت Java Development Kit (JDK)
- JDK 8 أو أحدث مطلوب
- يمكن استخدام OpenJDK أو Oracle JDK

## خطوات البناء

### 1. إعداد المشروع
```bash
# استنساخ المشروع أو نسخ الملفات
cd /path/to/AnimeChat

# التأكد من صلاحيات gradle wrapper
chmod +x gradlew
```

### 2. تحديث إعدادات الخادم
قم بتحديث عنوان الخادم في الملف:
`app/src/main/java/com/animechat/data/network/NetworkModule.kt`

```kotlin
// غير العنوان من localhost إلى عنوان الخادم الفعلي
val apiService: ApiService by lazy {
    createApiService("http://YOUR_SERVER_IP:5000/api/")
}
```

### 3. إعداد مفاتيح API للذكاء الاصطناعي
في الملف `app/src/main/java/com/animechat/data/ai/AIManager.kt`:

```kotlin
// استبدل المفاتيح الوهمية بمفاتيح حقيقية
val response = openAIService.getChatCompletion("Bearer YOUR_ACTUAL_OPENAI_API_KEY", request)
```

### 4. بناء التطبيق

#### للتطوير (Debug Build):
```bash
./gradlew assembleDebug
```

#### للإنتاج (Release Build):
```bash
./gradlew assembleRelease
```

### 5. العثور على ملف APK
بعد البناء الناجح، ستجد ملف APK في:
- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release.apk`

## إعداد التوقيع للإصدار النهائي

### 1. إنشاء مفتاح التوقيع
```bash
keytool -genkey -v -keystore anime-chat-key.keystore -alias anime-chat -keyalg RSA -keysize 2048 -validity 10000
```

### 2. إضافة إعدادات التوقيع
أضف إلى `app/build.gradle`:

```gradle
android {
    signingConfigs {
        release {
            storeFile file('anime-chat-key.keystore')
            storePassword 'your_store_password'
            keyAlias 'anime-chat'
            keyPassword 'your_key_password'
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

## استكشاف الأخطاء

### مشاكل شائعة وحلولها:

1. **خطأ في إصدار Gradle:**
   ```bash
   ./gradlew wrapper --gradle-version 8.0
   ```

2. **مشاكل في الذاكرة:**
   ```bash
   export GRADLE_OPTS="-Xmx4g -XX:MaxPermSize=512m"
   ```

3. **مشاكل في SDK:**
   - تأكد من تثبيت Android SDK Platform 34
   - تأكد من تثبيت Android Build Tools 34.0.0

4. **مشاكل في الشبكة:**
   - تأكد من أن الخادم يعمل على المنفذ 5000
   - تحقق من إعدادات الجدار الناري

## اختبار التطبيق

### 1. على المحاكي:
```bash
# تشغيل المحاكي
emulator -avd YOUR_AVD_NAME

# تثبيت التطبيق
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 2. على جهاز حقيقي:
- فعل وضع المطور على الجهاز
- فعل USB Debugging
- قم بتوصيل الجهاز وتثبيت التطبيق

## ملاحظات مهمة

1. **الخادم:** تأكد من تشغيل الخادم قبل اختبار التطبيق
2. **الشبكة:** التطبيق يحتاج اتصال بالإنترنت للعمل
3. **الأذونات:** التطبيق يطلب أذونات الإنترنت والكاميرا والتخزين
4. **API Keys:** لا تنس إضافة مفاتيح API الحقيقية للذكاء الاصطناعي

## الميزات المتاحة

- ✅ تسجيل الدخول والتسجيل
- ✅ الدردشة الفورية
- ✅ إنشاء وإدارة غرف الدردشة
- ✅ لوحة تحكم المدير
- ✅ ميزات الذكاء الاصطناعي
- ✅ واجهة مستخدم سوداوية احترافية
- ✅ دعم اللغة العربية

## الدعم

للحصول على المساعدة أو الإبلاغ عن مشاكل، يرجى التواصل مع فريق التطوير.

